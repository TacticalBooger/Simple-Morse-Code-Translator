A simple Java Morse Code Translator. Used to translate Morse Characters to English Words and English Words into Morse Characters.

Functionalities include: Inputs from user, Hashmaps, both-ways translations, checks if the user inputs incorrect values, comments to help guide other programmers.

Features only 1 class and no GUI, everything is done and displayed on the console.