import java.util.*;
import java.util.Scanner;

public class MorseCode1 {
    
    public static void main(String[] args)
    {
        // Morse Code Array List, contains all the alphabet characters in order.
        String[] mcode
            = { ".-",   "-...", "-.-.", "-..",  ".",
                "..-.", "--.",  "....", "..",   ".---",
                "-.-",  ".-..", "--",   "-.",   "---",
                ".--.", "--.-", ".-.",  "...",  "-",
                "..-",  "...-", ".--",  "-..-", "-.--",
                "--..", "|" };
        
        // Ask user for input on MORSE then SCANNER. Input nothing if you only want to use one of the functions.
           Scanner input = new Scanner(System.in);
           System.out.println("Please enter your MORSE CODE text (Separate each letter by a space): ");
           String morseCode = input.nextLine();
           System.out.println(" "); //Used to add a blank line to make the display more tidy.
           System.out.println("Please enter your ENGLISH text (One word at a time only): ");
           String englishLang = input.nextLine();
       
        // MORSE > ENGLISH METHOD
        morseToEnglish(mcode, morseCode);
       
        System.out.println();
        System.out.println();
       
        // ENGLISH > MORSE METHOD
        englishToMorse(mcode, englishLang);
    }
    
    
    //Entire method has Try / Catch incase an invalid input is placed, resulting in an error message.
    public static void morseToEnglish(String[] code,
                                      String morseCode) {
    try {
        // MORSE > ENGLISH HASHMAPS
        Map<String, Character> morseToEnglish //Key - String, Object - Character, Hashmaps need these to identify the characters to swap.
            = new HashMap<>();
        
        
        // HASHMAP'S SIZE (From 0 to 26)
        for (int i = 0; i < 26; i++) {
            morseToEnglish.put(code[i], (char)('a' + i)); //Increments inputted MORSE TEXT's position and swaps it with English accordingly.
        }
        
        
        // SPLIT MORSE CODE IN ARRAY OF STRINGS
        String[] array = morseCode.split(" "); //When inputting MORSE TEXT from user, each MORSE LETTER is separated by a space, otherwise user get's NULL.
        System.out.println("---------------------------------------------------------------------------------------------");
        System.out.print("MORSE CODE:      " + morseCode
                         + "      TO ENGLISH IS:      ");
        
        
        // MORSE > ENGLISH
        for (int i = 0; i < array.length; i++) {
            System.out.print(morseToEnglish.get(array[i]) //Collects all the inputted MORSE LETTERS and loops them for the display.
                             + "");
        }
    }
    
    catch (Exception e) {
        System.out.println(" "); //Used to add a blank line to make the display more tidy.
        System.out.println(" "); //Used to add a blank line to make the display more tidy.
        System.out.println("INVALID INPUT! Please input only the accepted values for MORSE and ENGLISH!");
        
    }
    }
    
    
    //Entire method has Try / Catch incase an invalid input is placed, resulting in an error message.
    public static void englishToMorse(String[] code,
                                      String englishLang){
            
    try {
        // ENGLISH > MORSE
        System.out.print("ENGLISH:      " + englishLang + "      TO MORSE CODE IS:      ");
        for (int i = 0; i < englishLang.length(); i++) { 
            System.out.print(
                code[englishLang.charAt(i) - 'a'] + " "); //Increments position of the inputted ENGLISH LETTERS and swaps them accordingly with charAt.
        }
        System.out.println(" ");
                                      }
    
    catch (Exception e) {
        System.out.println(" ");
        System.out.println(" ");
        System.out.println("INVALID INPUT! Please input only the accepted values for MORSE and ENGLISH!");
    }
    }
}